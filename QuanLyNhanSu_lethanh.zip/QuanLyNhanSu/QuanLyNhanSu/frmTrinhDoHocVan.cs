﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyNhanSu
{
    public partial class frmTrinhDoHocVan : Form
    {
        public frmTrinhDoHocVan()
        {
            InitializeComponent();
        }

        private void frmTrinhDoHocVan_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("Bạn có muốn thoát quản lý trình độ học vấn không?","Thông báo",MessageBoxButtons.YesNo) != System.Windows.Forms.DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }

        private void txtMaTDHV_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtMaTDHV, "You must enter Your name");
            else
                this.errorProvider1.Clear();
        }

        private void txtTenTDHV_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtTenTDHV, "You must enter Your name");
            else
                this.errorProvider1.Clear();
        }

        private void txtChuyenNganh_Leave(object sender, EventArgs e)
        {
            Control ctr = (Control)sender;
            if (ctr.Text.Trim().Length == 0)
                this.errorProvider1.SetError(txtChuyenNganh, "You must enter Your name");
            else
                this.errorProvider1.Clear();
        }

        private void txtTenTDHV_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length > 0 && char.IsDigit(ctr.Text, ctr.Text.Trim().Length - 1))
                {
                    this.errorProvider1.SetError(txtTenTDHV, "Hãy nhập kí tự");
                    txtTenTDHV.Clear();
                }
                else
                {
                    this.errorProvider1.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể nhập số vào ô tên" + ex.Message);
            }
        }

        private void btnThoatTDHV_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

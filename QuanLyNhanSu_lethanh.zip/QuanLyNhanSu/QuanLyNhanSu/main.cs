﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyNhanSu
{
    public partial class frmmain : Form
    {
        public frmmain()
        {
            InitializeComponent();
        }

        private void quảnLýChúcVụToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChucVu frmcv = new frmChucVu();
            frmcv.MdiParent = this;
            frmcv.Show();
        }

        private void quảnLýPhòngBanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPhongBan frmpb = new frmPhongBan();
            frmpb.MdiParent = this;
            frmpb.Show();
        }

        private void quảnLýTìnhĐộHọcVấnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTrinhDoHocVan frmTDHV = new frmTrinhDoHocVan();
            frmTDHV.MdiParent = this;
            frmTDHV.Show();
        }

       

    }
}

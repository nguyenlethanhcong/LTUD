﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace QuanLyNhanSu
{
    public partial class frmPhongBan : Form
    {
        public frmPhongBan()
        {
            InitializeComponent();
        }

        private void frmPhongBan_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát quản lý phòng ban không?", "Thông báo", MessageBoxButtons.YesNo) != System.Windows.Forms.DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }

        private void txtTenPB_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length > 0 && char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                {
                    this.errorProvider1.SetError(txtTenPB, "Bạn hãy nhập kí tự");
                    MessageBox.Show("Bạn hãy nhập kí tự","Thông báo");
                    txtTenPB.Clear();
                }
                else
                    this.errorProvider1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể nhập số");
            }
        }

        private void txtSDT_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length > 0 && !char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                {
                    this.errorProvider1.SetError(txtSDT, "Bạn hãy nhập con số");
                    MessageBox.Show("Bạn hãy nhập con số", "Thông báo");
                    txtSDT.Clear();
                }
                else
                    this.errorProvider1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể nhập chữ");
            }
        }

        private void btnQuaylai_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnThemPhongBan_Click(object sender, EventArgs e)
        {
            try
            {
              

                if (!char.IsDigit(txtTenPB.Text, txtTenPB.Text.Trim().Length - 1) && char.IsDigit(txtSDT.Text, txtSDT.Text.Trim().Length - 1))
                {
                    ListViewItem listview = new ListViewItem(txtMaPB.Text);
                    listview.SubItems.Add(txtTenPB.Text);
                    listview.SubItems.Add(txtDiaChi.Text);
                    listview.SubItems.Add(txtSDT.Text);
                    lvwPhongBan.Items.Add(listview);
                    txtTenPB.Clear();//xóa những kí tự đã nhập trên ô lastName
                    txtDiaChi.Clear();//
                    txtSDT.Clear();  // 
                    txtMaPB.Clear();
                    txtMaPB.Focus();//xóa bộ nhớ đệm
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void txtDiaChi_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length == 0)
                {
                    this.errorProvider1.SetError(txtDiaChi, "Bạn hãy nhập ");
 
                    txtDiaChi.Clear();
                }
                else
                    this.errorProvider1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtMaPB_Leave(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length == 0)
                {
                    this.errorProvider1.SetError(txtMaPB, "Bạn hãy nhập ");
                    
                    txtMaPB.Clear();
                }
                else
                    this.errorProvider1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtMaPB_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

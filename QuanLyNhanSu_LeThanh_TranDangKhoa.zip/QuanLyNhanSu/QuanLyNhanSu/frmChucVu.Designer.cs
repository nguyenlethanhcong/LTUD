﻿namespace QuanLyNhanSu
{
    partial class frmChucVu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaChucVu = new System.Windows.Forms.TextBox();
            this.txtTenCV = new System.Windows.Forms.TextBox();
            this.btnXoaCV = new System.Windows.Forms.Button();
            this.btnQuayLai = new System.Windows.Forms.Button();
            this.btnThemCV = new System.Windows.Forms.Button();
            this.btnSuaCV = new System.Windows.Forms.Button();
            this.lvwChucVu = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(223, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ CHỨC VỤ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mã Chức vụ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(115, 151);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên Chức Vụ";
            // 
            // txtMaChucVu
            // 
            this.txtMaChucVu.Location = new System.Drawing.Point(230, 101);
            this.txtMaChucVu.Margin = new System.Windows.Forms.Padding(2);
            this.txtMaChucVu.Name = "txtMaChucVu";
            this.txtMaChucVu.Size = new System.Drawing.Size(118, 20);
            this.txtMaChucVu.TabIndex = 3;
            this.txtMaChucVu.TextChanged += new System.EventHandler(this.txtMaChucVu_TextChanged);
            this.txtMaChucVu.Leave += new System.EventHandler(this.txtMaChucVu_Leave);
            // 
            // txtTenCV
            // 
            this.txtTenCV.Location = new System.Drawing.Point(230, 150);
            this.txtTenCV.Margin = new System.Windows.Forms.Padding(2);
            this.txtTenCV.Name = "txtTenCV";
            this.txtTenCV.Size = new System.Drawing.Size(118, 20);
            this.txtTenCV.TabIndex = 4;
            this.txtTenCV.TextChanged += new System.EventHandler(this.txtTenCV_TextChanged);
            // 
            // btnXoaCV
            // 
            this.btnXoaCV.Location = new System.Drawing.Point(230, 219);
            this.btnXoaCV.Margin = new System.Windows.Forms.Padding(2);
            this.btnXoaCV.Name = "btnXoaCV";
            this.btnXoaCV.Size = new System.Drawing.Size(77, 29);
            this.btnXoaCV.TabIndex = 5;
            this.btnXoaCV.Text = "XÓA";
            this.btnXoaCV.UseVisualStyleBackColor = true;
            // 
            // btnQuayLai
            // 
            this.btnQuayLai.Location = new System.Drawing.Point(230, 270);
            this.btnQuayLai.Margin = new System.Windows.Forms.Padding(2);
            this.btnQuayLai.Name = "btnQuayLai";
            this.btnQuayLai.Size = new System.Drawing.Size(77, 25);
            this.btnQuayLai.TabIndex = 6;
            this.btnQuayLai.Text = "QUAY LẠI";
            this.btnQuayLai.UseVisualStyleBackColor = true;
            this.btnQuayLai.Click += new System.EventHandler(this.btnQuayLai_Click);
            // 
            // btnThemCV
            // 
            this.btnThemCV.Location = new System.Drawing.Point(118, 219);
            this.btnThemCV.Margin = new System.Windows.Forms.Padding(2);
            this.btnThemCV.Name = "btnThemCV";
            this.btnThemCV.Size = new System.Drawing.Size(70, 29);
            this.btnThemCV.TabIndex = 7;
            this.btnThemCV.Text = "THÊM";
            this.btnThemCV.UseVisualStyleBackColor = true;
            this.btnThemCV.Click += new System.EventHandler(this.btnThemCV_Click);
            // 
            // btnSuaCV
            // 
            this.btnSuaCV.Location = new System.Drawing.Point(118, 270);
            this.btnSuaCV.Margin = new System.Windows.Forms.Padding(2);
            this.btnSuaCV.Name = "btnSuaCV";
            this.btnSuaCV.Size = new System.Drawing.Size(70, 25);
            this.btnSuaCV.TabIndex = 8;
            this.btnSuaCV.Text = "SỬA";
            this.btnSuaCV.UseVisualStyleBackColor = true;
            // 
            // lvwChucVu
            // 
            this.lvwChucVu.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvwChucVu.FullRowSelect = true;
            this.lvwChucVu.Location = new System.Drawing.Point(403, 93);
            this.lvwChucVu.Margin = new System.Windows.Forms.Padding(2);
            this.lvwChucVu.Name = "lvwChucVu";
            this.lvwChucVu.Size = new System.Drawing.Size(316, 289);
            this.lvwChucVu.TabIndex = 9;
            this.lvwChucVu.UseCompatibleStateImageBehavior = false;
            this.lvwChucVu.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã Chức Vụ";
            this.columnHeader1.Width = 172;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên Chức Vụ";
            this.columnHeader2.Width = 289;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmChucVu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 412);
            this.Controls.Add(this.lvwChucVu);
            this.Controls.Add(this.btnSuaCV);
            this.Controls.Add(this.btnThemCV);
            this.Controls.Add(this.btnQuayLai);
            this.Controls.Add(this.btnXoaCV);
            this.Controls.Add(this.txtTenCV);
            this.Controls.Add(this.txtMaChucVu);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.Name = "frmChucVu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Chức Vụ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmChucVu_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaChucVu;
        private System.Windows.Forms.TextBox txtTenCV;
        private System.Windows.Forms.Button btnXoaCV;
        private System.Windows.Forms.Button btnQuayLai;
        private System.Windows.Forms.Button btnThemCV;
        private System.Windows.Forms.Button btnSuaCV;
        private System.Windows.Forms.ListView lvwChucVu;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}
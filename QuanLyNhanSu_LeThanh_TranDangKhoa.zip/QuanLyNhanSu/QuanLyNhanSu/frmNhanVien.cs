﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyNhanSu
{
    public partial class frmNhanVien : Form
    {
        public frmNhanVien()
        {
            InitializeComponent();
        }
        private void frmNhanVien_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát quản lý nhân viên không?", "Thông báo", MessageBoxButtons.YesNo) != System.Windows.Forms.DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                if(!char.IsDigit(txtMaNV.Text,txtMaNV.Text.Trim().Length -1)
                    && !char.IsDigit(txtHoTen.Text,txtHoTen.Text.Trim().Length -1)
                    && !char.IsDigit(txtQueQuan.Text, txtQueQuan.Text.Trim().Length - 1)
                    )
                {
                ListViewItem dulieu = new ListViewItem();
                dulieu.Text = txtMaNV.Text;
                dulieu.SubItems.Add(txtHoTen.Text);
                dulieu.SubItems.Add(nrNgay.Value.ToString() + "/"+ nrThang.Value.ToString() + "/" + nrNam.Value.ToString());
                dulieu.SubItems.Add(txtQueQuan.Text);
                dulieu.SubItems.Add(nrLuong.Value.ToString());
                dulieu.SubItems.Add(cbPhong.Text);
                lstXuat.Items.Add(dulieu);
                txtMaNV.Clear();
                txtHoTen.Clear();
                txtQueQuan.Clear();
                txtMaNV.Focus();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Bạn chưa nhập đầy đủ thông tin!!!!");
            }
        }

        private void txtMaNV_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length > 0 && char.IsDigit(ctr.Text, ctr.Text.Trim().Length - 1))
                {
                    this.errorProvider1.SetError(txtMaNV, "Hãy nhập kí tự");
                }
                else
                {
                    this.errorProvider1.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể nhập số vào ô tên" + ex.Message);
            }
        }

    }
}

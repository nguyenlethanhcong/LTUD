﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyNhanSu
{
    public partial class frmChucVu : Form
    {
        public frmChucVu()
        {
            InitializeComponent();
        }
        private void frmChucVu_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát quản lý chức vụ không?", "Thông báo", MessageBoxButtons.YesNo) != System.Windows.Forms.DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }
        private void txtTenCV_TextChanged(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length > 0 && char.IsDigit(ctr.Text, ctr.Text.Length - 1))
                {
                    this.errorProvider1.SetError(txtTenCV, "Bạn hãy nhập kí tự");
                    MessageBox.Show("Bạn hãy nhập kí tự", "Thông báo");
                    txtTenCV.Clear();
                }
                else
                    this.errorProvider1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể nhập số");
            }
        }

        private void btnThemCV_Click(object sender, EventArgs e)
        {
            try
            {


                if (txtMaChucVu != null && txtTenCV != null && !char.IsDigit(txtTenCV.Text, txtTenCV.Text.Trim().Length - 1))
                {
                    ListViewItem listview = new ListViewItem();
                    listview.Text = txtMaChucVu.Text;
                    listview.SubItems.Add(txtTenCV.Text);
                    lvwChucVu.Items.Add(listview);        
                    txtTenCV.Clear();//
                    txtMaChucVu.Clear();//  
                    txtMaChucVu.Focus();//xóa bộ nhớ đệm
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtMaChucVu_Leave(object sender, EventArgs e)
        {
            try
            {
                Control ctr = (Control)sender;
                if (ctr.Text.Trim().Length == 0)
                {
                    this.errorProvider1.SetError(txtMaChucVu, "Bạn hãy nhập ");
                    MessageBox.Show("Bạn hãy nhập ", "Thông báo");
                   
                }
                else
                    this.errorProvider1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtMaChucVu_TextChanged(object sender, EventArgs e)
        {

        }



    }
}
